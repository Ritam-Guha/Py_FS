from Py_FS.evaluation.evaluate import evaluate

__all__ = [
    'evaluate'
]
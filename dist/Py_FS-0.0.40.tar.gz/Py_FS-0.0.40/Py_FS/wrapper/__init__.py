import wrapper.nature_inspired

__all__ = [
    "nature_inspired"
]
from Py_FS.wrapper.nature_inspired.GA import GA
from Py_FS.wrapper.nature_inspired.WOA import WOA

__all__ = [
    "GA",
    "WOA"
]
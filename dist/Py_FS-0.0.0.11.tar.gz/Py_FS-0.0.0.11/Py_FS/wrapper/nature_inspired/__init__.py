from Py_FS.wrapper.nature_inspired.GA import GA

__all__ = [
    'GA'
]
import Py_FS.wrapper.nature_inspired

__all__ = [
    'nature_inspired'
]